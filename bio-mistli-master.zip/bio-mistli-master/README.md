<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://gitlab.com/uploads/-/system/project/avatar/27954565/Screen_Capture_select-area_20210704212646.png" width="400"></a></p>

## Bio-Mistli

Prototipo funcional básico de la plataforma web para OBIO.
Back-end: Laravel
Front-end: Vue
