<template>
<nav v-if="!['login', 'register', null].includes(currentRoute)" class="navbar navbar-expand-md navbar-light bg-obio-secondary shadow-sm">
    <div class="container">
        <router-link :to="{name: 'welcome'}" class="navbar-brand">
            <span v-if="currentRoute === 'welcome'">OBIO</span>
            <span v-else><img src="/assets/img/obio.png" alt="" style="width: 25%"></span>
        </router-link>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->

                <li v-if="!usuario" class="nav-item">
                    <router-link :to="{name: 'login'}" class="nav-link">Login</router-link>
                </li>

                <li v-if="!usuario" class="nav-item">
                    <router-link :to="{name: 'register'}" class="nav-link">Registro</router-link>
                </li>

                <li v-if="usuario" class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {{ usuario.us_nombre }}
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a v-if="usuario.us_rol >= 2" class="dropdown-item" href="/admin/info-peliculas">
                            Administración
                        </a>

                        <a class="dropdown-item" href="/logout"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                            Cerrar sesión
                        </a>

                        <form id="logout-form" action="/logout" method="POST" class="d-none">
                            <input type="hidden" name="_token" :value="csrf">
                        </form>
                    </div>
                </li>

            </ul>
        </div>
    </div>
</nav>
</template>

<script>
import store from '../store';

export default {
    store,
    props: ['auth', 'csrf'],
    mounted(){
        this.$store.commit("CSRF", this.csrf);

        // Si viene una cadena vacía, significa que no está autenticado, por lo que pasaremos explicitamente un false, de lo contrario, aplicaremos un .parse a la cadena
        // con la información del usuario autenticado, para guardar un objeto
        const user = this.auth === '' ? false : JSON.parse(this.auth);

        this.$store.commit("USUARIO", user);
    },
    computed: {
        usuario(){
            return this.$store.state.usuario;
        },
        currentRoute() {
            return this.$route.name;
        }
    }
}
</script>
