<template>
    <div>
        <vue-page-transition name="overlay-left-full">
            <router-view :old="old"></router-view>
        </vue-page-transition>
    </div>
</template>

<script>
    import store from '../store';

    export default {
        store,
        props: ['old']
    }
</script>
