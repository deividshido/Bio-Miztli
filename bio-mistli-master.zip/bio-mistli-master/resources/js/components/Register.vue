<template>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Registro</div>

                <div class="card-body">
                    <form method="POST" action="/register">
                        <input type="hidden" name="_token" :value="csrf">

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">Nombre</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" v-model="old_data.name" required autocomplete="name" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="nacimiento" class="col-md-4 col-form-label text-md-right">Año de nacimiento</label>

                            <div class="col-md-6">
                                <input id="nacimiento" type="number" class="form-control" name="nacimiento" v-model="old_data.nacimiento" required autocomplete="nacimiento">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="genero" class="col-md-4 col-form-label text-md-right">Género</label>
                            <div class="col-md-6 mt-1">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="genero" id="F" value="F" v-model="old_data.genero">
                                    <label class="form-check-label" for="F">Femenino</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="genero" id="M" value="M" v-model="old_data.genero">
                                    <label class="form-check-label" for="M">Masculino</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="genero" id="O" value="O" v-model="old_data.genero">
                                    <label class="form-check-label" for="O">Otro</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="codigo" class="col-md-4 col-form-label text-md-right">Código postal</label>

                            <div class="col-md-6">
                                <input id="codigo" type="number" class="form-control" name="codigo" v-model="old_data.codigo" required autocomplete="codigo">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Correo electrónico</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" v-model="old_data.email" required autocomplete="email">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email_confirm" class="col-md-4 col-form-label text-md-right">Confirmar correo electrónico</label>

                            <div class="col-md-6">
                                <input id="email_confirm" type="email" class="form-control" name="email_confirmation" required autocomplete="email">
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">Contraseña</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirmar contraseña</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="terminos" id="terminos">

                                    <label class="form-check-label" for="terminos">
                                        Acepta términos y condiciones
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrarse
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
<script>
export default {
    props: ['old'],
    mounted(){
        document.querySelector('body').classList.remove('welcome');
        // document.querySelector('nav.navbar').classList.remove('transparente');
    },
    computed: {
        csrf(){
            return this.$store.state.csrf;
        },
        old_data(){
            const old_data = JSON.parse(this.old);

            return Object.keys(old_data).length == 0 ? {name: '', nacimiento: '', email: '', genero: '', codigo: ''} : old_data;
        }
    }
}
</script>
