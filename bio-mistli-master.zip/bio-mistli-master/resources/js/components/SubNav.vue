<template>
<div class="row justify-content-around subnav">
    <router-link :to="{name: 'welcome'}" class="col-2 btn btn-danger">Inicio</router-link>

    <router-link :to="{name: 'welcome'}" class="col-2 btn btn-danger">Conocenos</router-link>

    <router-link :to="{name: 'tienda'}" class="col-2 btn btn-danger">Tienda</router-link>

    <router-link :to="{name: 'promociones'}" class="col-2 btn btn-danger">Promociones</router-link>

    <router-link :to="{name: 'welcome'}" class="col-2 btn btn-danger">Ecoturismo</router-link>
</div>
</template>

<script>
export default {

}
</script>
