<template>
<div>
    <sub-nav></sub-nav>

    <div class="row mt-5">
        <div class="col-3">
            <div class="card">
                <div class="card__side card__side--front card__side--front-1"></div>

                <div class="card__side card__side--back card__side--back-1">
                    <div class="card__cta">
                        <div class="card__price-box">
                            <ul>
                                <li>
                                    Café Orgánico Tostado y Molido
                                </li>
                                <li>
                                    Café Orgánico Gourmet Tostado y Molido
                                </li>
                                <li>
                                    Café Orgánico en Grano Tostado
                                </li>
                                <li>
                                    Café Liofilizado
                                </li>
                                <li>
                                    Café Orgánico Soluble
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-3">
            <div class="card">
                <div class="card__side card__side--front card__side--front-2"></div>

                <div class="card__side card__side--back card__side--back-2">
                    <div class="card__cta">
                        <div class="card__price-box">
                            <ul>
                                <li>
                                    Miel Diferenciada por Floración
                                </li>
                                <li>
                                    Miel Multiflora Orgánica
                                </li>
                                <li>
                                    Miel Multiflora Mantequilla
                                </li>
                                <li>
                                    Miel de abeja Melipona
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="col-3">
            <div class="card">
                <div class="card__side card__side--front card__side--front-3"></div>

                <div class="card__side card__side--back card__side--back-3">
                    <div class="card__cta">
                        <div class="card__price-box">
                            <ul>
                                <li>
                                    Chocolate Miel con Cacao untable
                                </li>
                                <li>
                                    Nibs de Cacao
                                </li>
                                <li>
                                    Barra de Licor de Cacao
                                </li>
                                <li>
                                    Barra de Chocolate Oscuro
                                </li>
                                <li>
                                    Barra de Chocolate de Mesa
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-3">
            <div class="card">
                <div class="card__side card__side--front card__side--front-4"></div>

                <div class="card__side card__side--back card__side--back-4">
                    <div class="card__cta">
                        <div class="card__price-box">
                            <ul>
                                <li>
                                    Artesanías de madera
                                </li>
                                <li>
                                    Artesanías de hojas de pino
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import SubNav from './SubNav';

export default {
    components:{
        SubNav
    },
    mounted(){
        document.querySelector('body').classList.remove('welcome');
        document.querySelector('nav.navbar').classList.remove('transparente');
    },
}
</script>
