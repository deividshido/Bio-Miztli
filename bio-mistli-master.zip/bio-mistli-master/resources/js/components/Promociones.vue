<template>
    <sub-nav></sub-nav>
</template>

<script>
import SubNav from './SubNav';

export default {
    components:{
        SubNav
    },
    mounted(){
        document.querySelector('body').classList.remove('welcome');
        document.querySelector('nav.navbar').classList.remove('transparente');
    },
}
</script>
